﻿/**
 * Created with JetBrains PhpStorm.
 * User: xuheng
 * Date: 12-8-8
 * Time: 下午2:00
 * To change this template use File | Settings | File Templates.
 */
var templates = [
    {
        "pre": "pre0.png",
        'title': "上学帮",
        'preHtml': '',
        "html": '<a href="#" class="linkBox"><span class="linkIcon"><img src="//cdn.sxkid.com/images/www/v4/icon/article_linkbox_school.png" alt="上学帮" /></span><span class="linkTop"><em>上学帮</em><strong>标题标题标题</strong></span><span class="linkBtn">打开</span><span class="linkImg"><img src="https://file.sxkid.com/images/qrcode_gz.png" alt="" /></span></a>'
    },
    {
        "pre": "pre0.png",
        'title': "上学帮院校库",
        'preHtml': '',
        "html": '<a href="#" class="linkBox"><span class="linkIcon"><img src="//cdn.sxkid.com/images/www/v4/icon/article_linkbox_school.png" alt="上学帮院校库" /></span><span class="linkTop"><em>上学帮院校库</em><strong>标题标题标题</strong></span><span class="linkBtn">打开</span><span class="linkImg"><img src="https://file.sxkid.com/images/qrcode_gz.png" alt="" /></span></a>'
    },
    {
        "pre": "pre0.png",
        'title': "上学帮微课堂",
        'preHtml': '',
        "html": '<a href="#" class="linkBox"><span class="linkIcon"><img src="//cdn.sxkid.com/images/www/v4/icon/article_linkbox_lecture.png" alt="上学帮微课堂" /></span><span class="linkTop"><em>上学帮微课堂</em><strong>标题标题标题</strong></span><span class="linkBtn">打开</span><span class="linkImg"><img src="https://file.sxkid.com/images/qrcode_gz.png" alt="" /></span></a>'
    }
];